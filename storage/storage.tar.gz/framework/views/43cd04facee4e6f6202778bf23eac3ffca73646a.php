<!-- Sections Menu-->
<div class="nav-section-menu">
    <div class="nav nav-list">
        <span class="nav-header">In This Section</span>
        <a href="<?php echo e(route('services', 'mobile-application-development')); ?>" class="nav-link first <?php if($service == 'mobile-application-development'): ?> active <?php endif; ?>">
            Mobile Applications
            <small class="d-none d-lg-block">Cross Platform Mobile App Development</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'desktop-application-development')); ?>" class="nav-link <?php if($service == 'desktop-application-development'): ?> active <?php endif; ?>">
            Desktop Applications
            <small class="d-none d-lg-block">Cross Platform PC Software</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'web-cloud-application-development')); ?>" class="nav-link <?php if($service == 'web-cloud-application-development'): ?> active <?php endif; ?>">
            Web/Cloud Applications
            <small class="d-none d-lg-block">Platform/Device Independent Apps</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'website-development')); ?>" class="nav-link <?php if($service == 'website-development'): ?> active <?php endif; ?>">
            Websites
            <small class="d-none d-lg-block">Get a Website</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'home-office-network')); ?>" class="nav-link <?php if($service == 'home-office-network'): ?> active <?php endif; ?>">
            Home &amp; Office Network
            <small class="d-none d-lg-block">Get your Devices Communicating</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'tracking')); ?>" class="nav-link <?php if($service == 'tracking'): ?> active <?php endif; ?>">
            Locator &amp; Tracker
            <small class="d-none d-lg-block">GPS Tracking &amp; More</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'surveillance-systems')); ?>" class="nav-link <?php if($service == 'surveillance-systems'): ?> active <?php endif; ?>">
            Surveillance Systems
            <small class="d-none d-lg-block">CCTV Monitoring &amp; More</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'photo-video-coverage')); ?>" class="nav-link <?php if($service == 'photo-video-coverage'): ?> active <?php endif; ?>">
            Photo &amp; Video Coverage
            <small class="d-none d-lg-block">Keep memories of your events</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'multimedia-productions')); ?>" class="nav-link <?php if($service == 'multimedia-productions'): ?> active <?php endif; ?>">
            Multimedia Productions
            <small class="d-none d-lg-block">Video &amp; Audio Editing</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'system-administration-maintenance')); ?>" class="nav-link <?php if($service == 'system-administration-maintenance'): ?> active <?php endif; ?>">
            System Admin &amp; Maintenance
            <small class="d-none d-lg-block">PC Administration and Maintenance</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'consultancy-services')); ?>" class="nav-link <?php if($service == 'consultancy-services'): ?> active <?php endif; ?>">
            Consultancy Services
            <small class="d-none d-lg-block">Giving you insight on ICT issues</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('services', 'office-equipment-supply')); ?>" class="nav-link <?php if($service == 'office-equipment-supply'): ?> active <?php endif; ?>">
            Office Equipment Supply
            <small class="d-none d-lg-block">Supply of Digital Communication Devices</small>
            <i class="fa fa-angle-right"></i>
        </a>
    </div>
</div>
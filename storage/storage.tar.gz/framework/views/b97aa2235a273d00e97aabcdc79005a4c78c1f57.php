<!-- Sections Menu-->
<div class="nav-section-menu">
    <div class="nav nav-list">
        <span class="nav-header">In This Section</span>
        <a href="<?php echo e(route('about', 'about-us')); ?>" class="nav-link first <?php if($about == 'about-us'): ?> active <?php endif; ?>">
            Raines Technologies
            <small>About Us</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('about', 'terms')); ?>" class="nav-link <?php if($about == 'terms'): ?> active <?php endif; ?>">
            Terms
            <small>Our Company Terms</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('about', 'privacy')); ?>" class="nav-link <?php if($about == 'privacy'): ?> active <?php endif; ?>">
            Privacy
            <small>Our company privacy statement</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('about', 'channels')); ?>" class="nav-link <?php if($about == 'channels'): ?> active <?php endif; ?>">
            Channels of Communication
            <small>Ways to get in touch with Us</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="<?php echo e(route('contact')); ?>" class="nav-link <?php if($about == 'contact-us'): ?> active <?php endif; ?>">
            Contact Us
            <small>Get in touch with us now!</small>
            <i class="fa fa-angle-right"></i>
        </a>
    </div>
</div>
<div class="alert" role="alert" id="resp-alert" style="display:none;">
    <h4 class="alert-heading" id="title"></h4>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <hr>
    <p id="body"></p>
</div>
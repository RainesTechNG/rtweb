<!-- Sections Menu-->
<div class="nav-section-menu">
    <div class="nav nav-list">
        <span class="nav-header">In This Section</span>
        <a href="#" class="nav-link first active">
            Raines Technologies
            <small>About Us</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Website &amp; Web Applications
            <small>Application Development</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Desktop &amp; Mobile Applications
            <small>Application Development</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Home &amp; Office Networks
            <small>Systems Networking Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Photo &amp; Video Coverage
            <small>Multimedia Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Video Invitations &amp; Editing
            <small>Multimedia Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Home &amp; Office Security
            <small>Security System Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            CCTV/Surveillance System
            <small>Security System Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Automobile Locator
            <small>Security System Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Human &amp; Animal Tracking
            <small>Security System Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
        <a href="#" class="nav-link">
            Computer Administration &amp; Maintenance
            <small>General IT Services</small>
            <i class="fa fa-angle-right"></i>
        </a>
    </div>
</div>